README for group_17_assignment6.pde 

open the group_17_assignment6.pde and click 'run'. 
click mouse once to spawn bouncing stars.
click mouse multiple times to spawn fireworks at mouse position.