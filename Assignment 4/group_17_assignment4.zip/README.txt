README for group_17_assignment4.pde

* must have sound library installed to run. 

instructions to install sound library:
- open processing file
- click sketch on the top bar > import library > add library
- under the libraries tab, click on filter and type in sound
- select sound from the options listed and click on the install button near the bottom right

instructions to run file: 
- once the sound library is installed, open the main file "group_17_assignment4.pde" located in the group_17_assignment4 folder and click run.
note: it may take 30 seconds to load the window before the program starts running